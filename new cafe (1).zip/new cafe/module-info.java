module cafe.management {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.desktop;
    
    exports cafe;
    exports cafe.models;
    exports cafe.services;
}
