package cafe.services;

import cafe.models.*;
import java.util.ArrayList;
import java.util.List;

public class OrderService {
    private List<Order> orders;
    private int nextOrderId;
    
    public OrderService() {
        this.orders = new ArrayList<>();
        this.nextOrderId = 1001; // Start order IDs from 1001
    }
    
    public Order createOrder(Customer customer) {
        Order newOrder = new Order(nextOrderId++, customer);
        orders.add(newOrder);
        return newOrder;
    }
    
    public boolean addItemToOrder(int orderId, MenuItem menuItem, int quantity) {
        Order order = getOrder(orderId);
        if (order != null && menuItem.isAvailable()) {
            order.addItem(menuItem, quantity);
            return true;
        }
        return false;
    }
    
    public boolean removeItemFromOrder(int orderId, MenuItem menuItem) {
        Order order = getOrder(orderId);
        if (order != null) {
            order.removeItem(menuItem);
            return true;
        }
        return false;
    }
    
    public Order getOrder(int orderId) {
        for (Order order : orders) {
            if (order.getOrderId() == orderId) {
                return order;
            }
        }
        return null;
    }
    
    public boolean updateOrderStatus(int orderId, String status) {
        Order order = getOrder(orderId);
        if (order != null) {
            order.setStatus(status);
            return true;
        }
        return false;
    }
    
    public List<Order> getAllOrders() {
        return new ArrayList<>(orders);
    }
    
    public List<Order> getOrdersByCustomer(Customer customer) {
        List<Order> customerOrders = new ArrayList<>();
        for (Order order : orders) {
            if (order.getCustomer().getUsername().equals(customer.getUsername())) {
                customerOrders.add(order);
            }
        }
        return customerOrders;
    }
    
    public List<Order> getOrdersByStatus(String status) {
        List<Order> statusOrders = new ArrayList<>();
        for (Order order : orders) {
            if (order.getStatus().equals(status)) {
                statusOrders.add(order);
            }
        }
        return statusOrders;
    }
    
    public boolean completeOrder(int orderId, String paymentMethod) {
        Order order = getOrder(orderId);
        if (order != null) {
            order.setPaymentMethod(paymentMethod);
            order.setStatus("Completed");
            
            // Add loyalty points to customer (1 point per 100 PKR)
            int loyaltyPoints = (int) (order.getTotalAmount() / 100);
            order.getCustomer().addLoyaltyPoints(loyaltyPoints);
            
            return true;
        }
        return false;
    }
    
    public double getTotalRevenue() {
        return orders.stream()
                .filter(order -> "Completed".equals(order.getStatus()))
                .mapToDouble(Order::getTotalAmount)
                .sum();
    }
    
    public int getTotalOrdersCount() {
        return orders.size();
    }
    
    public int getCompletedOrdersCount() {
        return (int) orders.stream()
                .filter(order -> "Completed".equals(order.getStatus()))
                .count();
    }
}
