package cafe.services;

import cafe.models.*;
import java.util.ArrayList;
import java.util.List;

public class UserService {
    private List<User> users;
    private User currentUser;
    
    public UserService() {
        this.users = new ArrayList<>();
        initializeDefaultUsers();
    }
    
    private void initializeDefaultUsers() {
        // Create default admin
        Admin defaultAdmin = new Admin("admin", "admin123", "admin@cafe.com", 
                                     "System Administrator", "Super Admin");
        users.add(defaultAdmin);
        
        // Create sample employees
        Employee emp1 = new Employee("emp001", "emp123", "waiter@cafe.com", 
                                   "Ahmad Ali", "Waiter", 25000, "Service");
        Employee emp2 = new Employee("emp002", "emp123", "chef@cafe.com", 
                                   "Fatima Khan", "Chef", 35000, "Kitchen");
        users.add(emp1);
        users.add(emp2);
    }
    
    // Method overloading (Polymorphism)
    public boolean login(String username, String password) {
        for (User user : users) {
            if (user.getUsername().equals(username) && user.getPassword().equals(password)) {
                currentUser = user;
                return true;
            }
        }
        return false;
    }
    
    public User login(String username, String password, String role) {
        for (User user : users) {
            if (user.getUsername().equals(username) && 
                user.getPassword().equals(password) && 
                user.getRole().equals(role)) {
                currentUser = user;
                return user;
            }
        }
        return null;
    }
    
    public boolean registerCustomer(String username, String password, String email, 
                                  String fullName, String phoneNumber, String address) {
        // Check if username already exists
        for (User user : users) {
            if (user.getUsername().equals(username)) {
                return false;
            }
        }
        
        Customer newCustomer = new Customer(username, password, email, fullName, phoneNumber, address);
        users.add(newCustomer);
        return true;
    }
    
    public boolean addEmployee(String username, String password, String email, String fullName,
                             String position, double salary, String department) {
        // Check if username already exists
        for (User user : users) {
            if (user.getUsername().equals(username)) {
                return false;
            }
        }
        
        Employee newEmployee = new Employee(username, password, email, fullName, position, salary, department);
        users.add(newEmployee);
        return true;
    }
    
    public boolean deleteEmployee(String username) {
        return users.removeIf(user -> user.getUsername().equals(username) && user instanceof Employee);
    }
    
    public List<Employee> getAllEmployees() {
        List<Employee> employees = new ArrayList<>();
        for (User user : users) {
            if (user instanceof Employee) {
                employees.add((Employee) user);
            }
        }
        return employees;
    }
    
    public Employee getEmployee(String username) {
        for (User user : users) {
            if (user.getUsername().equals(username) && user instanceof Employee) {
                return (Employee) user;
            }
        }
        return null;
    }
    
    public boolean updateEmployee(String username, String position, double salary, String department) {
        Employee employee = getEmployee(username);
        if (employee != null) {
            employee.setPosition(position);
            employee.setSalary(salary);
            employee.setDepartment(department);
            return true;
        }
        return false;
    }
    
    public User getCurrentUser() {
        return currentUser;
    }
    
    public void logout() {
        currentUser = null;
    }
    
    public List<User> getAllUsers() {
        return new ArrayList<>(users);
    }
}
