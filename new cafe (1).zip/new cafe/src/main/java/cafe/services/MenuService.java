package cafe.services;

import cafe.models.*;
import java.util.ArrayList;
import java.util.List;

public class MenuService {
    private List<MenuItem> menuItems;
    private int nextItemId;
    
    public MenuService() {
        this.menuItems = new ArrayList<>();
        this.nextItemId = 1;
        initializeDefaultMenu();
    }
    
    private void initializeDefaultMenu() {
        // Chinese Dishes
        addChineseDish("Chicken Chow Mein", "Stir-fried noodles with chicken and vegetables", 
                      450.0, "Medium", false, "Stir-fried");
        addChineseDish("Sweet and Sour Chicken", "Crispy chicken with sweet and sour sauce", 
                      520.0, "Mild", false, "Deep-fried");
        addChineseDish("Vegetable Spring Rolls", "Crispy rolls filled with fresh vegetables", 
                      280.0, "Mild", true, "Deep-fried");
        addChineseDish("Beef Black Bean", "Tender beef with black bean sauce", 
                      580.0, "Medium", false, "Stir-fried");
        addChineseDish("Kung Pao Chicken", "Spicy chicken with peanuts and vegetables", 
                      500.0, "Hot", false, "Stir-fried");
        
        // Pakistani Beverages
        addPakistaniBeverage("Chai", "Traditional Pakistani tea with milk and spices", 
                           80.0, "Hot", false, "Medium");
        addPakistaniBeverage("Lassi", "Yogurt-based traditional drink", 
                           120.0, "Cold", false, "Large");
        addPakistaniBeverage("Rooh Afza", "Rose-flavored refreshing drink", 
                           100.0, "Cold", false, "Medium");
        addPakistaniBeverage("Kashmiri Chai", "Pink tea with almonds and cardamom", 
                           150.0, "Hot", false, "Medium");
        addPakistaniBeverage("Fresh Lime Water", "Fresh lime juice with mint", 
                           90.0, "Cold", true, "Medium");
    }
    
    public boolean addChineseDish(String name, String description, double price, 
                                String spiceLevel, boolean isVegetarian, String cookingStyle) {
        ChineseDish dish = new ChineseDish(nextItemId++, name, description, price, 
                                         spiceLevel, isVegetarian, cookingStyle);
        return menuItems.add(dish);
    }
    
    public boolean addPakistaniBeverage(String name, String description, double price, 
                                      String temperature, boolean isSugarFree, String size) {
        PakistaniBeverage beverage = new PakistaniBeverage(nextItemId++, name, description, price, 
                                                         temperature, isSugarFree, size);
        return menuItems.add(beverage);
    }
    
    public boolean deleteMenuItem(int itemId) {
        return menuItems.removeIf(item -> item.getItemId() == itemId);
    }
    
    public MenuItem getMenuItem(int itemId) {
        for (MenuItem item : menuItems) {
            if (item.getItemId() == itemId) {
                return item;
            }
        }
        return null;
    }
    
    public boolean updateMenuItem(int itemId, String name, String description, double price) {
        MenuItem item = getMenuItem(itemId);
        if (item != null) {
            item.setName(name);
            item.setDescription(description);
            item.setPrice(price);
            return true;
        }
        return false;
    }
    
    public List<MenuItem> getAllMenuItems() {
        return new ArrayList<>(menuItems);
    }
    
    public List<MenuItem> getMenuItemsByCategory(String category) {
        List<MenuItem> categoryItems = new ArrayList<>();
        for (MenuItem item : menuItems) {
            if (item.getCategory().equals(category)) {
                categoryItems.add(item);
            }
        }
        return categoryItems;
    }
    
    public List<ChineseDish> getChineseDishes() {
        List<ChineseDish> dishes = new ArrayList<>();
        for (MenuItem item : menuItems) {
            if (item instanceof ChineseDish) {
                dishes.add((ChineseDish) item);
            }
        }
        return dishes;
    }
    
    public List<PakistaniBeverage> getPakistaniBeverages() {
        List<PakistaniBeverage> beverages = new ArrayList<>();
        for (MenuItem item : menuItems) {
            if (item instanceof PakistaniBeverage) {
                beverages.add((PakistaniBeverage) item);
            }
        }
        return beverages;
    }
    
    public void toggleItemAvailability(int itemId) {
        MenuItem item = getMenuItem(itemId);
        if (item != null) {
            item.setAvailable(!item.isAvailable());
        }
    }
}
