package cafe;

import cafe.services.*;
import cafe.models.*;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.PasswordField;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.control.cell.TextFieldListCell;
import javafx.util.StringConverter;

public class CafeManagementApp extends Application {
    
    private UserService userService;
    private MenuService menuService;
    private OrderService orderService;
    private Stage primaryStage;
    
    // Theme Colors
    private static final String PRIMARY_COLOR = "#FF6B35"; // Orange
    private static final String SECONDARY_COLOR = "#1A1A1A"; // Black
    private static final String ACCENT_COLOR = "#FF8C42"; // Light Orange
    private static final String TEXT_COLOR = "#FFFFFF"; // White
    private static final String BACKGROUND_COLOR = "#2D2D2D"; // Dark Gray
    
    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;
        
        // Initialize services
        userService = new UserService();
        menuService = new MenuService();
        orderService = new OrderService();
        
        // Set up the primary stage
        primaryStage.setTitle("SpiceItUp - Cafe Management System");
        primaryStage.setWidth(900);
        primaryStage.setHeight(700);
        
        // Show login screen
        showLoginScreen();
        
        primaryStage.show();
    }
    
    private VBox createLogo() {
        VBox logoBox = new VBox(5);
        logoBox.setAlignment(Pos.CENTER);
        
        // Create a stylized logo using shapes
        HBox logoContainer = new HBox(10);
        logoContainer.setAlignment(Pos.CENTER);
        
        // Spice icon (circle with flame effect)
        Circle spiceIcon = new Circle(25);
        spiceIcon.setFill(Color.web(PRIMARY_COLOR));
        spiceIcon.setStroke(Color.web(ACCENT_COLOR));
        spiceIcon.setStrokeWidth(3);
        
        // Add drop shadow effect
        DropShadow shadow = new DropShadow();
        shadow.setColor(Color.web(PRIMARY_COLOR));
        shadow.setRadius(10);
        spiceIcon.setEffect(shadow);
        
        // Logo text
        Text logoText = new Text("SpiceItUp");
        logoText.setFont(Font.font("Arial", FontWeight.BOLD, 36));
        logoText.setFill(Color.web(PRIMARY_COLOR));
        
        Text tagline = new Text("🌶️ Authentic Flavors, Modern Service 🌶️");
        tagline.setFont(Font.font("Arial", FontWeight.NORMAL, 14));
        tagline.setFill(Color.web(ACCENT_COLOR));
        
        logoContainer.getChildren().addAll(spiceIcon, logoText);
        logoBox.getChildren().addAll(logoContainer, tagline);
        
        return logoBox;
    }
    
    private void showLoginScreen() {
        VBox mainContainer = new VBox(30);
        mainContainer.setAlignment(Pos.CENTER);
        mainContainer.setPadding(new Insets(40));
        mainContainer.setStyle(
            "-fx-background-color: linear-gradient(to bottom, " + SECONDARY_COLOR + ", " + BACKGROUND_COLOR + ");"
        );
        
        // Logo
        VBox logo = createLogo();
        
        // Login card
        VBox loginCard = new VBox(25);
        loginCard.setAlignment(Pos.CENTER);
        loginCard.setPadding(new Insets(40));
        loginCard.setMaxWidth(400);
        loginCard.setStyle(
            "-fx-background-color: " + SECONDARY_COLOR + ";" +
            "-fx-background-radius: 15;" +
            "-fx-border-color: " + PRIMARY_COLOR + ";" +
            "-fx-border-width: 2;" +
            "-fx-border-radius: 15;" +
            "-fx-effect: dropshadow(gaussian, rgba(255, 107, 53, 0.3), 20, 0, 0, 0);"
        );
        
        // Welcome text
        Label welcomeLabel = new Label("🔐 Welcome Back!");
        welcomeLabel.setStyle(
            "-fx-font-size: 24px;" +
            "-fx-font-weight: bold;" +
            "-fx-text-fill: " + PRIMARY_COLOR + ";"
        );
        
        // Login form
        VBox loginForm = new VBox(15);
        loginForm.setAlignment(Pos.CENTER);
        
        // Role selection
        Label roleLabel = new Label("👤 Select Role:");
        roleLabel.setStyle("-fx-text-fill: " + TEXT_COLOR + "; -fx-font-size: 14px; -fx-font-weight: bold;");
        
        ComboBox<String> roleComboBox = createStyledComboBox();
        roleComboBox.getItems().addAll("🔧 Admin", "👨‍💼 Employee", "🛍️ Customer");
        roleComboBox.setValue("🛍️ Customer");
        roleComboBox.setPrefWidth(300);
        
        // Username field
        Label usernameLabel = new Label("📧 Username:");
        usernameLabel.setStyle("-fx-text-fill: " + TEXT_COLOR + "; -fx-font-size: 14px; -fx-font-weight: bold;");
        
        TextField usernameField = new TextField();
        usernameField.setPromptText("Enter your username");
        usernameField.setStyle(
            "-fx-background-color: " + BACKGROUND_COLOR + ";" +
            "-fx-text-fill: " + TEXT_COLOR + ";" +
            "-fx-prompt-text-fill: #888888;" +
            "-fx-border-color: " + PRIMARY_COLOR + ";" +
            "-fx-border-radius: 5;" +
            "-fx-padding: 12;" +
            "-fx-font-size: 14px;"
        );
        usernameField.setPrefWidth(300);
        
        // Password field
        Label passwordLabel = new Label("🔒 Password:");
        passwordLabel.setStyle("-fx-text-fill: " + TEXT_COLOR + "; -fx-font-size: 14px; -fx-font-weight: bold;");
        
        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Enter your password");
        passwordField.setStyle(
            "-fx-background-color: " + BACKGROUND_COLOR + ";" +
            "-fx-text-fill: " + TEXT_COLOR + ";" +
            "-fx-prompt-text-fill: #888888;" +
            "-fx-border-color: " + PRIMARY_COLOR + ";" +
            "-fx-border-radius: 5;" +
            "-fx-padding: 12;" +
            "-fx-font-size: 14px;"
        );
        passwordField.setPrefWidth(300);
        
        // Buttons
        HBox buttonBox = new HBox(15);
        buttonBox.setAlignment(Pos.CENTER);
        
        Button loginButton = createStyledButton("🚀 Login", PRIMARY_COLOR, TEXT_COLOR);
        loginButton.setPrefWidth(140);
        
        Button registerButton = createStyledButton("📝 Register", ACCENT_COLOR, TEXT_COLOR);
        registerButton.setPrefWidth(140);
        
        buttonBox.getChildren().addAll(loginButton, registerButton);
        
        // Add components to form
        loginForm.getChildren().addAll(
            roleLabel, roleComboBox,
            usernameLabel, usernameField,
            passwordLabel, passwordField,
            buttonBox
        );
        
        loginCard.getChildren().addAll(welcomeLabel, loginForm);
        mainContainer.getChildren().addAll(logo, loginCard);
        
        // Event handlers
        loginButton.setOnAction(e -> {
            String username = usernameField.getText();
            String password = passwordField.getText();
            String role = roleComboBox.getValue().split(" ")[1]; // Extract role without emoji
            
            if (username.isEmpty() || password.isEmpty()) {
                showStyledAlert("❌ Error", "Please fill in all fields.");
                return;
            }
            
            if (userService.login(username, password)) {
                if (userService.getCurrentUser().getRole().equals(role)) {
                    switch (role) {
                        case "Admin":
                            showAdminDashboard();
                            break;
                        case "Employee":
                            showEmployeeDashboard();
                            break;
                        case "Customer":
                            showCustomerDashboard();
                            break;
                    }
                } else {
                    showStyledAlert("❌ Error", "Invalid role selected for this user.");
                }
            } else {
                showStyledAlert("❌ Error", "Invalid username or password.");
            }
        });
        
        registerButton.setOnAction(e -> showCustomerRegistration());
        
        Scene scene = new Scene(mainContainer);
        primaryStage.setScene(scene);
    }
    
    private Button createStyledButton(String text, String bgColor, String textColor) {
        Button button = new Button(text);
        button.setStyle(
            "-fx-background-color: " + bgColor + ";" +
            "-fx-text-fill: " + textColor + ";" +
            "-fx-font-weight: bold;" +
            "-fx-font-size: 14px;" +
            "-fx-padding: 12 20;" +
            "-fx-background-radius: 25;" +
            "-fx-border-radius: 25;" +
            "-fx-cursor: hand;" +
            "-fx-effect: dropshadow(gaussian, rgba(0, 0, 0, 0.3), 5, 0, 0, 2);"
        );
        
        // Hover effect
        button.setOnMouseEntered(e -> button.setStyle(
            "-fx-background-color: derive(" + bgColor + ", 20%);" +
            "-fx-text-fill: " + textColor + ";" +
            "-fx-font-weight: bold;" +
            "-fx-font-size: 14px;" +
            "-fx-padding: 12 20;" +
            "-fx-background-radius: 25;" +
            "-fx-border-radius: 25;" +
            "-fx-cursor: hand;" +
            "-fx-effect: dropshadow(gaussian, rgba(0, 0, 0, 0.5), 8, 0, 0, 3);"
        ));
        
        button.setOnMouseExited(e -> button.setStyle(
            "-fx-background-color: " + bgColor + ";" +
            "-fx-text-fill: " + textColor + ";" +
            "-fx-font-weight: bold;" +
            "-fx-font-size: 14px;" +
            "-fx-padding: 12 20;" +
            "-fx-background-radius: 25;" +
            "-fx-border-radius: 25;" +
            "-fx-cursor: hand;" +
            "-fx-effect: dropshadow(gaussian, rgba(0, 0, 0, 0.3), 5, 0, 0, 2);"
        ));
        
        return button;
    }
    
    private void showCustomerRegistration() {
        Stage registrationStage = new Stage();
        registrationStage.setTitle("SpiceItUp - Customer Registration");
        
        VBox mainContainer = new VBox(20);
        mainContainer.setPadding(new Insets(30));
        mainContainer.setAlignment(Pos.CENTER);
        mainContainer.setStyle(
            "-fx-background-color: linear-gradient(to bottom, " + SECONDARY_COLOR + ", " + BACKGROUND_COLOR + ");"
        );
        
        // Title
        Label titleLabel = new Label("🎉 Join SpiceItUp Family!");
        titleLabel.setStyle(
            "-fx-font-size: 28px;" +
            "-fx-font-weight: bold;" +
            "-fx-text-fill: " + PRIMARY_COLOR + ";"
        );
        
        // Registration form
        VBox regCard = new VBox(20);
        regCard.setPadding(new Insets(30));
        regCard.setMaxWidth(500);
        regCard.setStyle(
            "-fx-background-color: " + SECONDARY_COLOR + ";" +
            "-fx-background-radius: 15;" +
            "-fx-border-color: " + PRIMARY_COLOR + ";" +
            "-fx-border-width: 2;" +
            "-fx-border-radius: 15;"
        );
        
        GridPane regForm = new GridPane();
        regForm.setHgap(15);
        regForm.setVgap(15);
        regForm.setAlignment(Pos.CENTER);
        
        // Form fields with icons
        TextField usernameField = createStyledTextField("👤 Username");
        PasswordField passwordField = createStyledPasswordField("🔒 Password");
        TextField emailField = createStyledTextField("📧 Email");
        TextField fullNameField = createStyledTextField("👨‍💼 Full Name");
        TextField phoneField = createStyledTextField("📱 Phone Number");
        TextArea addressArea = createStyledTextArea("🏠 Address");
        
        regForm.add(createFieldLabel("Username:"), 0, 0);
        regForm.add(usernameField, 1, 0);
        regForm.add(createFieldLabel("Password:"), 0, 1);
        regForm.add(passwordField, 1, 1);
        regForm.add(createFieldLabel("Email:"), 0, 2);
        regForm.add(emailField, 1, 2);
        regForm.add(createFieldLabel("Full Name:"), 0, 3);
        regForm.add(fullNameField, 1, 3);
        regForm.add(createFieldLabel("Phone:"), 0, 4);
        regForm.add(phoneField, 1, 4);
        regForm.add(createFieldLabel("Address:"), 0, 5);
        regForm.add(addressArea, 1, 5);
        
        HBox buttonBox = new HBox(15);
        buttonBox.setAlignment(Pos.CENTER);
        
        Button registerBtn = createStyledButton("✅ Register", PRIMARY_COLOR, TEXT_COLOR);
        Button cancelBtn = createStyledButton("❌ Cancel", "#666666", TEXT_COLOR);
        
        buttonBox.getChildren().addAll(registerBtn, cancelBtn);
        
        regCard.getChildren().addAll(regForm, buttonBox);
        mainContainer.getChildren().addAll(titleLabel, regCard);
        
        registerBtn.setOnAction(e -> {
            if (userService.registerCustomer(
                usernameField.getText(),
                passwordField.getText(),
                emailField.getText(),
                fullNameField.getText(),
                phoneField.getText(),
                addressArea.getText()
            )) {
                showStyledAlert("✅ Success", "Registration successful! Welcome to SpiceItUp family!");
                registrationStage.close();
            } else {
                showStyledAlert("❌ Error", "Registration failed. Username might already exist.");
            }
        });
        
        cancelBtn.setOnAction(e -> registrationStage.close());
        
        Scene regScene = new Scene(mainContainer, 600, 700);
        registrationStage.setScene(regScene);
        registrationStage.show();
    }
    
    private TextField createStyledTextField(String promptText) {
        TextField field = new TextField();
        field.setPromptText(promptText);
        field.setStyle(
            "-fx-background-color: " + BACKGROUND_COLOR + ";" +
            "-fx-text-fill: " + TEXT_COLOR + ";" +
            "-fx-prompt-text-fill: #888888;" +
            "-fx-border-color: " + PRIMARY_COLOR + ";" +
            "-fx-border-radius: 8;" +
            "-fx-padding: 12;" +
            "-fx-font-size: 14px;" +
            "-fx-pref-width: 250px;"
        );
        return field;
    }

    private PasswordField createStyledPasswordField(String promptText) {
        PasswordField field = new PasswordField();
        field.setPromptText(promptText);
        field.setStyle(
            "-fx-background-color: " + BACKGROUND_COLOR + ";" +
            "-fx-text-fill: " + TEXT_COLOR + ";" +
            "-fx-prompt-text-fill: #888888;" +
            "-fx-border-color: " + PRIMARY_COLOR + ";" +
            "-fx-border-radius: 8;" +
            "-fx-padding: 12;" +
            "-fx-font-size: 14px;" +
            "-fx-pref-width: 250px;"
        );
        return field;
    }

    private TextArea createStyledTextArea(String promptText) {
        TextArea area = new TextArea();
        area.setPromptText(promptText);
        area.setPrefRowCount(3);
        area.setStyle(
            "-fx-background-color: " + BACKGROUND_COLOR + ";" +
            "-fx-text-fill: " + TEXT_COLOR + " !important;" +
            "-fx-prompt-text-fill: #888888;" +
            "-fx-border-color: " + PRIMARY_COLOR + ";" +
            "-fx-border-radius: 8;" +
            "-fx-padding: 12;" +
            "-fx-font-size: 14px;" +
            "-fx-pref-width: 250px;" +
            "-fx-control-inner-background: " + BACKGROUND_COLOR + ";" +
            "-fx-highlight-fill: " + PRIMARY_COLOR + ";" +
            "-fx-highlight-text-fill: " + TEXT_COLOR + ";"
        );
        
        // Force text color to be visible
        area.setOnMouseClicked(e -> {
            area.setStyle(
                "-fx-background-color: " + BACKGROUND_COLOR + ";" +
                "-fx-text-fill: " + TEXT_COLOR + " !important;" +
                "-fx-prompt-text-fill: #888888;" +
                "-fx-border-color: " + PRIMARY_COLOR + ";" +
                "-fx-border-radius: 8;" +
                "-fx-padding: 12;" +
                "-fx-font-size: 14px;" +
                "-fx-pref-width: 250px;" +
                "-fx-control-inner-background: " + BACKGROUND_COLOR + ";" +
                "-fx-highlight-fill: " + PRIMARY_COLOR + ";" +
                "-fx-highlight-text-fill: " + TEXT_COLOR + ";"
            );
        });
        
        return area;
    }

    private ComboBox<String> createStyledComboBox() {
        ComboBox<String> comboBox = new ComboBox<>();
        comboBox.setStyle(
            "-fx-background-color: " + BACKGROUND_COLOR + ";" +
            "-fx-text-fill: " + TEXT_COLOR + ";" +
            "-fx-border-color: " + PRIMARY_COLOR + ";" +
            "-fx-border-radius: 8;" +
            "-fx-padding: 10;" +
            "-fx-font-size: 14px;"
        );
        
        // Fix for dropdown items text color
        comboBox.setCellFactory(listView -> new javafx.scene.control.ListCell<String>() {
            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                    setStyle("-fx-background-color: transparent;");
                } else {
                    setText(item);
                    setStyle(
                        "-fx-background-color: " + BACKGROUND_COLOR + ";" +
                        "-fx-text-fill: " + TEXT_COLOR + ";" +
                        "-fx-padding: 8;"
                    );
                }
            }
        });
        
        // Fix for selected item text color
        comboBox.setButtonCell(new javafx.scene.control.ListCell<String>() {
            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                } else {
                    setText(item);
                    setStyle(
                        "-fx-background-color: " + BACKGROUND_COLOR + ";" +
                        "-fx-text-fill: " + TEXT_COLOR + ";"
                    );
                }
            }
        });
        
        return comboBox;
    }

    private ListView<String> createStyledListView() {
        ListView<String> listView = new ListView<>();
        listView.setStyle(
            "-fx-background-color: " + SECONDARY_COLOR + ";" +
            "-fx-border-color: " + PRIMARY_COLOR + ";" +
            "-fx-border-radius: 10;" +
            "-fx-background-radius: 10;" +
            "-fx-control-inner-background: " + SECONDARY_COLOR + ";"
        );
        
        // Fix for list items text color
        listView.setCellFactory(lv -> {
            TextFieldListCell<String> cell = new TextFieldListCell<>();
            cell.setConverter(new StringConverter<String>() {
                @Override
                public String toString(String object) {
                    return object;
                }
                
                @Override
                public String fromString(String string) {
                    return string;
                }
            });
            
            cell.setStyle(
                "-fx-background-color: " + SECONDARY_COLOR + ";" +
                "-fx-text-fill: " + TEXT_COLOR + ";" +
                "-fx-padding: 8;" +
                "-fx-font-size: 13px;"
            );
            
            return cell;
        });
        
        return listView;
    }
    
    private Label createFieldLabel(String text) {
        Label label = new Label(text);
        label.setStyle(
            "-fx-text-fill: " + TEXT_COLOR + ";" +
            "-fx-font-size: 14px;" +
            "-fx-font-weight: bold;"
        );
        return label;
    }
    
    private void showAdminDashboard() {
        VBox mainContainer = new VBox();
        mainContainer.setStyle(
            "-fx-background-color: " + BACKGROUND_COLOR + ";"
        );
        
        // Header
        HBox header = createDashboardHeader("🔧 Admin Dashboard", "Administrator");
        
        // Tab pane
        TabPane tabPane = new TabPane();
        tabPane.setStyle(
            "-fx-background-color: " + BACKGROUND_COLOR + ";" +
            "-fx-border-color: " + PRIMARY_COLOR + ";"
        );
        
        // Styled tabs
        Tab employeeTab = createStyledTab("👥 Employee Management", createEmployeeManagementPane());
        Tab menuTab = createStyledTab("🍽️ Menu Management", createMenuManagementPane());
        Tab orderTab = createStyledTab("📋 Order Management", createOrderManagementPane());
        Tab reportsTab = createStyledTab("📊 Reports", createReportsPane());
        
        tabPane.getTabs().addAll(employeeTab, menuTab, orderTab, reportsTab);
        
        mainContainer.getChildren().addAll(header, tabPane);
        VBox.setVgrow(tabPane, Priority.ALWAYS);
        
        Scene scene = new Scene(mainContainer, 1200, 800);
        primaryStage.setScene(scene);
    }
    
    private HBox createDashboardHeader(String title, String role) {
        HBox header = new HBox();
        header.setPadding(new Insets(15));
        header.setStyle(
            "-fx-background-color: linear-gradient(to right, " + SECONDARY_COLOR + ", " + PRIMARY_COLOR + ");"
        );
        header.setAlignment(Pos.CENTER_LEFT);
        
        // Logo and title
        VBox titleBox = new VBox(5);
        Label titleLabel = new Label(title);
        titleLabel.setStyle(
            "-fx-text-fill: " + TEXT_COLOR + ";" +
            "-fx-font-size: 24px;" +
            "-fx-font-weight: bold;"
        );
        
        Label welcomeLabel = new Label("Welcome, " + userService.getCurrentUser().getFullName() + " (" + role + ")");
        welcomeLabel.setStyle(
            "-fx-text-fill: " + ACCENT_COLOR + ";" +
            "-fx-font-size: 14px;"
        );
        
        titleBox.getChildren().addAll(titleLabel, welcomeLabel);
        
        // Logout button
        Button logoutBtn = createStyledButton("🚪 Logout", "#e74c3c", TEXT_COLOR);
        logoutBtn.setOnAction(e -> {
            userService.logout();
            showLoginScreen();
        });
        
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        
        header.getChildren().addAll(titleBox, spacer, logoutBtn);
        return header;
    }
    
    private Tab createStyledTab(String title, VBox content) {
        Tab tab = new Tab(title);
        tab.setContent(content);
        tab.setClosable(false);
        tab.setStyle(
            "-fx-background-color: " + SECONDARY_COLOR + ";" +
            "-fx-text-base-color: " + TEXT_COLOR + ";"
        );
        return tab;
    }
    
    private void showCustomerDashboard() {
        VBox mainContainer = new VBox();
        mainContainer.setStyle("-fx-background-color: " + BACKGROUND_COLOR + ";");
        
        // Header
        HBox header = createDashboardHeader("🛍️ Customer Dashboard", "Customer");
        
        // Content
        VBox contentBox = new VBox(25);
        contentBox.setPadding(new Insets(30));
        
        // Menu section
        VBox menuSection = new VBox(15);
        Label menuLabel = new Label("🍽️ Our Delicious Menu");
        menuLabel.setStyle(
            "-fx-font-size: 22px;" +
            "-fx-font-weight: bold;" +
            "-fx-text-fill: " + PRIMARY_COLOR + ";"
        );
        
        ListView<String> menuListView = createStyledListView();
        
        for (cafe.models.MenuItem item : menuService.getAllMenuItems()) {
            if (item.isAvailable()) {
                String itemText = item.getDisplayInfo();
                if (item instanceof ChineseDish) {
                    itemText = "🥢 " + itemText;
                } else if (item instanceof PakistaniBeverage) {
                    itemText = "🥤 " + itemText;
                }
                menuListView.getItems().add(itemText);
            }
        }
        
        Button placeOrderBtn = createStyledButton("🛒 Place Order", PRIMARY_COLOR, TEXT_COLOR);
        placeOrderBtn.setPrefWidth(200);
        placeOrderBtn.setOnAction(e -> showOrderPlacementDialog());
        
        menuSection.getChildren().addAll(menuLabel, menuListView, placeOrderBtn);
        contentBox.getChildren().add(menuSection);
        
        mainContainer.getChildren().addAll(header, contentBox);
        
        Scene scene = new Scene(mainContainer, 1000, 700);
        primaryStage.setScene(scene);
    }
    
    private void showEmployeeDashboard() {
        VBox mainContainer = new VBox();
        mainContainer.setStyle("-fx-background-color: " + BACKGROUND_COLOR + ";");
        
        // Header
        HBox header = createDashboardHeader("👨‍💼 Employee Dashboard", "Employee");
        
        // Content
        VBox contentBox = new VBox(30);
        contentBox.setPadding(new Insets(40));
        contentBox.setAlignment(Pos.CENTER);
        
        Label infoLabel = new Label("👋 Welcome to your workspace!");
        infoLabel.setStyle(
            "-fx-font-size: 24px;" +
            "-fx-font-weight: bold;" +
            "-fx-text-fill: " + PRIMARY_COLOR + ";"
        );
        
        Label descLabel = new Label("🔧 Employee features coming soon...");
        descLabel.setStyle(
            "-fx-font-size: 16px;" +
            "-fx-text-fill: " + TEXT_COLOR + ";"
        );
        
        contentBox.getChildren().addAll(infoLabel, descLabel);
        mainContainer.getChildren().addAll(header, contentBox);
        
        Scene scene = new Scene(mainContainer, 1000, 700);
        primaryStage.setScene(scene);
    }
    
    private VBox createEmployeeManagementPane() {
        VBox empPane = new VBox(20);
        empPane.setPadding(new Insets(25));
        empPane.setStyle("-fx-background-color: " + BACKGROUND_COLOR + ";");
        
        Label titleLabel = new Label("👥 Employee Management");
        titleLabel.setStyle(
            "-fx-font-size: 20px;" +
            "-fx-font-weight: bold;" +
            "-fx-text-fill: " + PRIMARY_COLOR + ";"
        );
        
        ListView<String> empListView = createStyledListView();
        refreshEmployeeList(empListView);
        
        HBox buttonBox = new HBox(15);
        buttonBox.setAlignment(Pos.CENTER);
        
        Button addEmpBtn = createStyledButton("➕ Add Employee", PRIMARY_COLOR, TEXT_COLOR);
        Button editEmpBtn = createStyledButton("✏️ Edit Employee", ACCENT_COLOR, TEXT_COLOR);
        Button deleteEmpBtn = createStyledButton("🗑️ Delete Employee", "#e74c3c", TEXT_COLOR);
        
        addEmpBtn.setOnAction(e -> showAddEmployeeDialog(empListView));
        deleteEmpBtn.setOnAction(e -> {
            String selected = empListView.getSelectionModel().getSelectedItem();
            if (selected != null) {
                String username = selected.split(" - ")[0].replace("Employee: ", "").split(" \\(")[1].replace(")", "");
                if (userService.deleteEmployee(username)) {
                    refreshEmployeeList(empListView);
                    showStyledAlert("✅ Success", "Employee deleted successfully.");
                } else {
                    showStyledAlert("❌ Error", "Failed to delete employee.");
                }
            }
        });
        
        buttonBox.getChildren().addAll(addEmpBtn, editEmpBtn, deleteEmpBtn);
        empPane.getChildren().addAll(titleLabel, empListView, buttonBox);
        
        return empPane;
    }
    
    private VBox createMenuManagementPane() {
        VBox menuPane = new VBox(20);
        menuPane.setPadding(new Insets(25));
        menuPane.setStyle("-fx-background-color: " + BACKGROUND_COLOR + ";");
        
        Label titleLabel = new Label("🍽️ Menu Management");
        titleLabel.setStyle(
            "-fx-font-size: 20px;" +
            "-fx-font-weight: bold;" +
            "-fx-text-fill: " + PRIMARY_COLOR + ";"
        );
        
        ListView<String> menuListView = createStyledListView();
        refreshMenuList(menuListView);
        
        HBox buttonBox = new HBox(15);
        buttonBox.setAlignment(Pos.CENTER);
        
        Button addChineseBtn = createStyledButton("🥢 Add Chinese Dish", PRIMARY_COLOR, TEXT_COLOR);
        Button addBeverageBtn = createStyledButton("🥤 Add Pakistani Beverage", ACCENT_COLOR, TEXT_COLOR);
        Button deleteItemBtn = createStyledButton("🗑️ Delete Item", "#e74c3c", TEXT_COLOR);
        
        addChineseBtn.setOnAction(e -> showAddChineseDishDialog(menuListView));
        addBeverageBtn.setOnAction(e -> showAddBeverageDialog(menuListView));
        
        buttonBox.getChildren().addAll(addChineseBtn, addBeverageBtn, deleteItemBtn);
        menuPane.getChildren().addAll(titleLabel, menuListView, buttonBox);
        
        return menuPane;
    }
    
    private VBox createOrderManagementPane() {
        VBox orderPane = new VBox(20);
        orderPane.setPadding(new Insets(25));
        orderPane.setStyle("-fx-background-color: " + BACKGROUND_COLOR + ";");
        
        Label titleLabel = new Label("📋 Order Management");
        titleLabel.setStyle(
            "-fx-font-size: 20px;" +
            "-fx-font-weight: bold;" +
            "-fx-text-fill: " + PRIMARY_COLOR + ";"
        );
        
        ListView<String> orderListView = createStyledListView();
        
        for (Order order : orderService.getAllOrders()) {
            orderListView.getItems().add("📦 Order #" + order.getOrderId() + " - " + 
                                       order.getCustomer().getFullName() + " - PKR " + 
                                       order.getTotalAmount() + " - " + order.getStatus());
        }
        
        orderPane.getChildren().addAll(titleLabel, orderListView);
        return orderPane;
    }
    
    private VBox createReportsPane() {
        VBox reportsPane = new VBox(20);
        reportsPane.setPadding(new Insets(25));
        reportsPane.setStyle("-fx-background-color: " + BACKGROUND_COLOR + ";");
        
        Label titleLabel = new Label("📊 Reports & Statistics");
        titleLabel.setStyle(
            "-fx-font-size: 20px;" +
            "-fx-font-weight: bold;" +
            "-fx-text-fill: " + PRIMARY_COLOR + ";"
        );
        
        VBox statsBox = new VBox(15);
        
        Label totalOrdersLabel = createStatLabel("📦 Total Orders: " + orderService.getTotalOrdersCount());
        Label completedOrdersLabel = createStatLabel("✅ Completed Orders: " + orderService.getCompletedOrdersCount());
        Label totalRevenueLabel = createStatLabel("💰 Total Revenue: PKR " + String.format("%.2f", orderService.getTotalRevenue()));
        Label totalEmployeesLabel = createStatLabel("👥 Total Employees: " + userService.getAllEmployees().size());
        Label totalMenuItemsLabel = createStatLabel("🍽️ Total Menu Items: " + menuService.getAllMenuItems().size());
        
        statsBox.getChildren().addAll(totalOrdersLabel, completedOrdersLabel, 
                                     totalRevenueLabel, totalEmployeesLabel, totalMenuItemsLabel);
        
        reportsPane.getChildren().addAll(titleLabel, statsBox);
        return reportsPane;
    }
    
    private Label createStatLabel(String text) {
        Label label = new Label(text);
        label.setStyle(
            "-fx-font-size: 16px;" +
            "-fx-text-fill: " + TEXT_COLOR + ";" +
            "-fx-padding: 10;" +
            "-fx-background-color: " + SECONDARY_COLOR + ";" +
            "-fx-background-radius: 8;" +
            "-fx-border-color: " + PRIMARY_COLOR + ";" +
            "-fx-border-radius: 8;"
        );
        return label;
    }
    
    // Continue with remaining methods...
    private void showAddEmployeeDialog(ListView<String> empListView) {
        Stage dialog = new Stage();
        dialog.setTitle("SpiceItUp - Add Employee");
        
        VBox mainContainer = new VBox(20);
        mainContainer.setPadding(new Insets(25));
        mainContainer.setStyle("-fx-background-color: " + BACKGROUND_COLOR + ";");
        
        Label titleLabel = new Label("➕ Add New Employee");
        titleLabel.setStyle(
            "-fx-font-size: 20px;" +
            "-fx-font-weight: bold;" +
            "-fx-text-fill: " + PRIMARY_COLOR + ";"
        );
        
        GridPane grid = new GridPane();
        grid.setHgap(15);
        grid.setVgap(15);
        grid.setPadding(new Insets(20));
        grid.setAlignment(Pos.CENTER);
        
        TextField usernameField = createStyledTextField("👤 Username");
        PasswordField passwordField = createStyledPasswordField("🔒 Password");
        TextField emailField = createStyledTextField("📧 Email");
        TextField fullNameField = createStyledTextField("👨‍💼 Full Name");
        TextField positionField = createStyledTextField("💼 Position");
        TextField salaryField = createStyledTextField("💰 Salary (PKR)");
        TextField departmentField = createStyledTextField("🏢 Department");
        
        grid.add(createFieldLabel("Username:"), 0, 0);
        grid.add(usernameField, 1, 0);
        grid.add(createFieldLabel("Password:"), 0, 1);
        grid.add(passwordField, 1, 1);
        grid.add(createFieldLabel("Email:"), 0, 2);
        grid.add(emailField, 1, 2);
        grid.add(createFieldLabel("Full Name:"), 0, 3);
        grid.add(fullNameField, 1, 3);
        grid.add(createFieldLabel("Position:"), 0, 4);
        grid.add(positionField, 1, 4);
        grid.add(createFieldLabel("Salary (PKR):"), 0, 5);
        grid.add(salaryField, 1, 5);
        grid.add(createFieldLabel("Department:"), 0, 6);
        grid.add(departmentField, 1, 6);
        
        HBox buttonBox = new HBox(15);
        buttonBox.setAlignment(Pos.CENTER);
        
        Button addBtn = createStyledButton("✅ Add Employee", PRIMARY_COLOR, TEXT_COLOR);
        Button cancelBtn = createStyledButton("❌ Cancel", "#666666", TEXT_COLOR);
        
        buttonBox.getChildren().addAll(addBtn, cancelBtn);
        
        mainContainer.getChildren().addAll(titleLabel, grid, buttonBox);
        
        addBtn.setOnAction(e -> {
            try {
                double salary = Double.parseDouble(salaryField.getText());
                if (userService.addEmployee(
                    usernameField.getText(),
                    passwordField.getText(),
                    emailField.getText(),
                    fullNameField.getText(),
                    positionField.getText(),
                    salary,
                    departmentField.getText()
                )) {
                    refreshEmployeeList(empListView);
                    showStyledAlert("✅ Success", "Employee added successfully!");
                    dialog.close();
                } else {
                    showStyledAlert("❌ Error", "Failed to add employee. Username might already exist.");
                }
            } catch (NumberFormatException ex) {
                showStyledAlert("❌ Error", "Please enter a valid salary amount.");
            }
        });
        
        cancelBtn.setOnAction(e -> dialog.close());
        
        Scene scene = new Scene(mainContainer, 500, 600);
        dialog.setScene(scene);
        dialog.show();
    }
    
    private void showAddChineseDishDialog(ListView<String> menuListView) {
        Stage dialog = new Stage();
        dialog.setTitle("SpiceItUp - Add Chinese Dish");
        
        VBox mainContainer = new VBox(20);
        mainContainer.setPadding(new Insets(25));
        mainContainer.setStyle("-fx-background-color: " + BACKGROUND_COLOR + ";");
        
        Label titleLabel = new Label("🥢 Add Chinese Dish");
        titleLabel.setStyle(
            "-fx-font-size: 20px;" +
            "-fx-font-weight: bold;" +
            "-fx-text-fill: " + PRIMARY_COLOR + ";"
        );
        
        GridPane grid = new GridPane();
        grid.setHgap(15);
        grid.setVgap(15);
        grid.setPadding(new Insets(20));
        grid.setAlignment(Pos.CENTER);
        
        TextField nameField = createStyledTextField("🍜 Dish Name");
        TextArea descArea = createStyledTextArea("📝 Description");
        TextField priceField = createStyledTextField("💰 Price (PKR)");
        TextField cookingStyleField = createStyledTextField("👨‍🍳 Cooking Style");
        
        ComboBox<String> spiceLevelBox = createStyledComboBox();
        spiceLevelBox.getItems().addAll("🌶️ Mild", "🌶️🌶️ Medium", "🌶️🌶️🌶️ Hot", "🌶️🌶️🌶️🌶️ Very Hot");
        spiceLevelBox.setValue("🌶️🌶️ Medium");
        
        CheckBox vegetarianBox = new CheckBox("🥬 Vegetarian");
        vegetarianBox.setStyle("-fx-text-fill: " + TEXT_COLOR + ";");
        
        grid.add(createFieldLabel("Name:"), 0, 0);
        grid.add(nameField, 1, 0);
        grid.add(createFieldLabel("Description:"), 0, 1);
        grid.add(descArea, 1, 1);
        grid.add(createFieldLabel("Price (PKR):"), 0, 2);
        grid.add(priceField, 1, 2);
        grid.add(createFieldLabel("Spice Level:"), 0, 3);
        grid.add(spiceLevelBox, 1, 3);
        grid.add(createFieldLabel("Vegetarian:"), 0, 4);
        grid.add(vegetarianBox, 1, 4);
        grid.add(createFieldLabel("Cooking Style:"), 0, 5);
        grid.add(cookingStyleField, 1, 5);
        
        HBox buttonBox = new HBox(15);
        buttonBox.setAlignment(Pos.CENTER);
        
        Button addBtn = createStyledButton("✅ Add Dish", PRIMARY_COLOR, TEXT_COLOR);
        Button cancelBtn = createStyledButton("❌ Cancel", "#666666", TEXT_COLOR);
        
        buttonBox.getChildren().addAll(addBtn, cancelBtn);
        
        mainContainer.getChildren().addAll(titleLabel, grid, buttonBox);
        
        addBtn.setOnAction(e -> {
            try {
                double price = Double.parseDouble(priceField.getText());
                String spiceLevel = spiceLevelBox.getValue().split(" ")[1]; // Remove emoji
                if (menuService.addChineseDish(
                    nameField.getText(),
                    descArea.getText(),
                    price,
                    spiceLevel,
                    vegetarianBox.isSelected(),
                    cookingStyleField.getText()
                )) {
                    refreshMenuList(menuListView);
                    showStyledAlert("✅ Success", "Chinese dish added successfully!");
                    dialog.close();
                } else {
                    showStyledAlert("❌ Error", "Failed to add dish.");
                }
            } catch (NumberFormatException ex) {
                showStyledAlert("❌ Error", "Please enter a valid price.");
            }
        });
        
        cancelBtn.setOnAction(e -> dialog.close());
        
        Scene scene = new Scene(mainContainer, 500, 600);
        dialog.setScene(scene);
        dialog.show();
    }
    
    private void showAddBeverageDialog(ListView<String> menuListView) {
        Stage dialog = new Stage();
        dialog.setTitle("SpiceItUp - Add Pakistani Beverage");
        
        VBox mainContainer = new VBox(20);
        mainContainer.setPadding(new Insets(25));
        mainContainer.setStyle("-fx-background-color: " + BACKGROUND_COLOR + ";");
        
        Label titleLabel = new Label("🥤 Add Pakistani Beverage");
        titleLabel.setStyle(
            "-fx-font-size: 20px;" +
            "-fx-font-weight: bold;" +
            "-fx-text-fill: " + PRIMARY_COLOR + ";"
        );
        
        GridPane grid = new GridPane();
        grid.setHgap(15);
        grid.setVgap(15);
        grid.setPadding(new Insets(20));
        grid.setAlignment(Pos.CENTER);
        
        TextField nameField = createStyledTextField("🥤 Beverage Name");
        TextArea descArea = createStyledTextArea("📝 Description");
        TextField priceField = createStyledTextField("💰 Price (PKR)");
        
        ComboBox<String> temperatureBox = createStyledComboBox();
        temperatureBox.getItems().addAll("🔥 Hot", "🧊 Cold", "🌡️ Room Temperature");
        temperatureBox.setValue("🧊 Cold");
        
        CheckBox sugarFreeBox = new CheckBox("🚫🍯 Sugar Free");
        sugarFreeBox.setStyle("-fx-text-fill: " + TEXT_COLOR + ";");
        
        ComboBox<String> sizeBox = createStyledComboBox();
        sizeBox.getItems().addAll("🥃 Small", "🥤 Medium", "🍺 Large");
        sizeBox.setValue("🥤 Medium");
        
        grid.add(createFieldLabel("Name:"), 0, 0);
        grid.add(nameField, 1, 0);
        grid.add(createFieldLabel("Description:"), 0, 1);
        grid.add(descArea, 1, 1);
        grid.add(createFieldLabel("Price (PKR):"), 0, 2);
        grid.add(priceField, 1, 2);
        grid.add(createFieldLabel("Temperature:"), 0, 3);
        grid.add(temperatureBox, 1, 3);
        grid.add(createFieldLabel("Sugar Free:"), 0, 4);
        grid.add(sugarFreeBox, 1, 4);
        grid.add(createFieldLabel("Size:"), 0, 5);
        grid.add(sizeBox, 1, 5);
        
        HBox buttonBox = new HBox(15);
        buttonBox.setAlignment(Pos.CENTER);
        
        Button addBtn = createStyledButton("✅ Add Beverage", PRIMARY_COLOR, TEXT_COLOR);
        Button cancelBtn = createStyledButton("❌ Cancel", "#666666", TEXT_COLOR);
        
        buttonBox.getChildren().addAll(addBtn, cancelBtn);
        
        mainContainer.getChildren().addAll(titleLabel, grid, buttonBox);
        
        addBtn.setOnAction(e -> {
            try {
                double price = Double.parseDouble(priceField.getText());
                String temperature = temperatureBox.getValue().split(" ")[1]; // Remove emoji
                String size = sizeBox.getValue().split(" ")[1]; // Remove emoji
                if (menuService.addPakistaniBeverage(
                    nameField.getText(),
                    descArea.getText(),
                    price,
                    temperature,
                    sugarFreeBox.isSelected(),
                    size
                )) {
                    refreshMenuList(menuListView);
                    showStyledAlert("✅ Success", "Pakistani beverage added successfully!");
                    dialog.close();
                } else {
                    showStyledAlert("❌ Error", "Failed to add beverage.");
                }
            } catch (NumberFormatException ex) {
                showStyledAlert("❌ Error", "Please enter a valid price.");
            }
        });
        
        cancelBtn.setOnAction(e -> dialog.close());
        
        Scene scene = new Scene(mainContainer, 500, 600);
        dialog.setScene(scene);
        dialog.show();
    }
    
    private void showOrderPlacementDialog() {
        Stage dialog = new Stage();
        dialog.setTitle("SpiceItUp - Place Order");
        
        VBox mainContainer = new VBox(20);
        mainContainer.setPadding(new Insets(25));
        mainContainer.setStyle("-fx-background-color: " + BACKGROUND_COLOR + ";");
        
        Label titleLabel = new Label("🛒 Place Your Order");
        titleLabel.setStyle(
            "-fx-font-size: 20px;" +
            "-fx-font-weight: bold;" +
            "-fx-text-fill: " + PRIMARY_COLOR + ";"
        );
        
        Customer customer = (Customer) userService.getCurrentUser();
        Order newOrder = orderService.createOrder(customer);
        
        HBox contentBox = new HBox(20);
        
        // Available items
        VBox availableBox = new VBox(15);
        Label availableLabel = new Label("🍽️ Available Items");
        availableLabel.setStyle(
            "-fx-font-size: 16px;" +
            "-fx-font-weight: bold;" +
            "-fx-text-fill: " + TEXT_COLOR + ";"
        );
        
        ListView<String> availableItems = createStyledListView();
        availableItems.setPrefWidth(300);
        
        for (cafe.models.MenuItem item : menuService.getAllMenuItems()) {
            if (item.isAvailable()) {
                String itemText = item.getItemId() + ": ";
                if (item instanceof ChineseDish) {
                    itemText += "🥢 " + item.getDisplayInfo();
                } else if (item instanceof PakistaniBeverage) {
                    itemText += "🥤 " + item.getDisplayInfo();
                }
                availableItems.getItems().add(itemText);
            }
        }
        
        availableBox.getChildren().addAll(availableLabel, availableItems);
        
        // Order items
        VBox orderBox = new VBox(15);
        Label orderLabel = new Label("🛒 Your Order");
        orderLabel.setStyle(
            "-fx-font-size: 16px;" +
            "-fx-font-weight: bold;" +
            "-fx-text-fill: " + TEXT_COLOR + ";"
        );
        
        ListView<String> orderItems = createStyledListView();
        orderItems.setPrefWidth(300);
        
        orderBox.getChildren().addAll(orderLabel, orderItems);
        
        contentBox.getChildren().addAll(availableBox, orderBox);
        
        // Controls
        HBox controlBox = new HBox(15);
        controlBox.setAlignment(Pos.CENTER);
        
        Label quantityLabel = new Label("Quantity:");
        quantityLabel.setStyle("-fx-text-fill: " + TEXT_COLOR + ";");
        
        TextField quantityField = createStyledTextField("Quantity");
        quantityField.setText("1");
        quantityField.setPrefWidth(100);
        
        Button addToOrderBtn = createStyledButton("➕ Add to Order", PRIMARY_COLOR, TEXT_COLOR);
        Button placeOrderBtn = createStyledButton("✅ Place Order", "#27ae60", TEXT_COLOR);
        Button cancelBtn = createStyledButton("❌ Cancel", "#666666", TEXT_COLOR);
        
        controlBox.getChildren().addAll(quantityLabel, quantityField, addToOrderBtn, placeOrderBtn, cancelBtn);
        
        mainContainer.getChildren().addAll(titleLabel, contentBox, controlBox);
        
        addToOrderBtn.setOnAction(e -> {
            String selected = availableItems.getSelectionModel().getSelectedItem();
            if (selected != null) {
                try {
                    int itemId = Integer.parseInt(selected.split(":")[0]);
                    int quantity = Integer.parseInt(quantityField.getText());
                    cafe.models.MenuItem menuItem = menuService.getMenuItem(itemId);
                    
                    if (orderService.addItemToOrder(newOrder.getOrderId(), menuItem, quantity)) {
                        String orderItemText = menuItem.getName() + " x" + quantity + 
                                             " = PKR " + menuItem.calculateTotal(quantity);
                        orderItems.getItems().add(orderItemText);
                    }
                } catch (NumberFormatException ex) {
                    showStyledAlert("❌ Error", "Please enter a valid quantity.");
                }
            }
        });
        
        placeOrderBtn.setOnAction(e -> {
            if (!newOrder.getOrderItems().isEmpty()) {
                orderService.completeOrder(newOrder.getOrderId(), "Cash");
                showStyledAlert("✅ Success", "Order placed successfully!\n\n" + newOrder.getOrderSummary());
                dialog.close();
            } else {
                showStyledAlert("❌ Error", "Please add items to your order.");
            }
        });
        
        cancelBtn.setOnAction(e -> dialog.close());
        
        Scene scene = new Scene(mainContainer, 700, 600);
        dialog.setScene(scene);
        dialog.show();
    }
    
    private void refreshEmployeeList(ListView<String> listView) {
        listView.getItems().clear();
        for (Employee emp : userService.getAllEmployees()) {
            listView.getItems().add("👨‍💼 " + emp.getDisplayInfo());
        }
    }
    
    private void refreshMenuList(ListView<String> listView) {
        listView.getItems().clear();
        for (cafe.models.MenuItem item : menuService.getAllMenuItems()) {
            String availability = item.isAvailable() ? "✅ Available" : "❌ Not Available";
            String itemText = "";
            if (item instanceof ChineseDish) {
                itemText = "🥢 " + item.getDisplayInfo() + " - " + availability;
            } else if (item instanceof PakistaniBeverage) {
                itemText = "🥤 " + item.getDisplayInfo() + " - " + availability;
            }
            listView.getItems().add(itemText);
        }
    }
    
    private void showStyledAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        
        // Style the alert
        alert.getDialogPane().setStyle(
            "-fx-background-color: " + SECONDARY_COLOR + ";" +
            "-fx-text-fill: " + TEXT_COLOR + ";" +
            "-fx-border-color: " + PRIMARY_COLOR + ";" +
            "-fx-border-width: 2;"
        );
        
        // Fix alert text color
        alert.getDialogPane().lookup(".content.label").setStyle("-fx-text-fill: " + TEXT_COLOR + ";");
        
        alert.showAndWait();
    }
    
    public static void main(String[] args) {
        launch(args);
    }
}
