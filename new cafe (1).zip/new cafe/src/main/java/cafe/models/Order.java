package cafe.models;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class Order {
    private int orderId;
    private Customer customer;
    private List<OrderItem> orderItems;
    private LocalDateTime orderTime;
    private String status; // Pending, Preparing, Ready, Delivered, Cancelled
    private double totalAmount;
    private String paymentMethod;
    
    public Order(int orderId, Customer customer) {
        this.orderId = orderId;
        this.customer = customer;
        this.orderItems = new ArrayList<>();
        this.orderTime = LocalDateTime.now();
        this.status = "Pending";
        this.totalAmount = 0.0;
    }
    
    // Encapsulation
    public int getOrderId() {
        return orderId;
    }
    
    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }
    
    public Customer getCustomer() {
        return customer;
    }
    
    public void setCustomer(Customer customer) {
        this.customer = customer;
    }
    
    public List<OrderItem> getOrderItems() {
        return orderItems;
    }
    
    public LocalDateTime getOrderTime() {
        return orderTime;
    }
    
    public String getStatus() {
        return status;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
    
    public double getTotalAmount() {
        return totalAmount;
    }
    
    public String getPaymentMethod() {
        return paymentMethod;
    }
    
    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }
    
    // Business methods
    public void addItem(MenuItem menuItem, int quantity) {
        OrderItem orderItem = new OrderItem(menuItem, quantity);
        orderItems.add(orderItem);
        calculateTotal();
    }
    
    public void removeItem(MenuItem menuItem) {
        orderItems.removeIf(item -> item.getMenuItem().getItemId() == menuItem.getItemId());
        calculateTotal();
    }
    
    private void calculateTotal() {
        totalAmount = orderItems.stream()
                .mapToDouble(item -> item.getMenuItem().calculateTotal(item.getQuantity()))
                .sum();
    }
    
    public String getOrderSummary() {
        StringBuilder summary = new StringBuilder();
        summary.append("Order #").append(orderId).append("\n");
        summary.append("Customer: ").append(customer.getFullName()).append("\n");
        summary.append("Items:\n");
        for (OrderItem item : orderItems) {
            summary.append("- ").append(item.getMenuItem().getName())
                   .append(" x").append(item.getQuantity())
                   .append(" = PKR ").append(item.getMenuItem().calculateTotal(item.getQuantity()))
                   .append("\n");
        }
        summary.append("Total: PKR ").append(totalAmount);
        return summary.toString();
    }
}
