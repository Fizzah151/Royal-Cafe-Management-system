package cafe.models;

// Inheritance - Admin extends User
public class Admin extends User {
    private String adminLevel;
    
    public Admin(String username, String password, String email, String fullName, String adminLevel) {
        super(username, password, email, fullName);
        this.adminLevel = adminLevel;
    }
    
    public String getAdminLevel() {
        return adminLevel;
    }
    
    public void setAdminLevel(String adminLevel) {
        this.adminLevel = adminLevel;
    }
    
    // Implementing abstract method
    @Override
    public String getRole() {
        return "Admin";
    }
    
    // Method overriding (Polymorphism)
    @Override
    public String getDisplayInfo() {
        return "Admin: " + getFullName() + " (" + getUsername() + ") - Level: " + adminLevel;
    }
}
