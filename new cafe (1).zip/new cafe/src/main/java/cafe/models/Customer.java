package cafe.models;

// Inheritance - Customer extends User
public class Customer extends User {
    private String phoneNumber;
    private String address;
    private int loyaltyPoints;
    
    public Customer(String username, String password, String email, String fullName, 
                   String phoneNumber, String address) {
        super(username, password, email, fullName);
        this.phoneNumber = phoneNumber;
        this.address = address;
        this.loyaltyPoints = 0;
    }
    
    // Encapsulation
    public String getPhoneNumber() {
        return phoneNumber;
    }
    
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
    
    public String getAddress() {
        return address;
    }
    
    public void setAddress(String address) {
        this.address = address;
    }
    
    public int getLoyaltyPoints() {
        return loyaltyPoints;
    }
    
    public void setLoyaltyPoints(int loyaltyPoints) {
        this.loyaltyPoints = loyaltyPoints;
    }
    
    public void addLoyaltyPoints(int points) {
        this.loyaltyPoints += points;
    }
    
    // Implementing abstract method
    @Override
    public String getRole() {
        return "Customer";
    }
    
    // Method overriding (Polymorphism)
    @Override
    public String getDisplayInfo() {
        return "Customer: " + getFullName() + " - Points: " + loyaltyPoints;
    }
}
