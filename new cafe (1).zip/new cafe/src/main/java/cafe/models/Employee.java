package cafe.models;

// Inheritance - Employee extends User
public class Employee extends User {
    private String position;
    private double salary;
    private String department;
    
    public Employee(String username, String password, String email, String fullName, 
                   String position, double salary, String department) {
        super(username, password, email, fullName);
        this.position = position;
        this.salary = salary;
        this.department = department;
    }
    
    // Encapsulation
    public String getPosition() {
        return position;
    }
    
    public void setPosition(String position) {
        this.position = position;
    }
    
    public double getSalary() {
        return salary;
    }
    
    public void setSalary(double salary) {
        this.salary = salary;
    }
    
    public String getDepartment() {
        return department;
    }
    
    public void setDepartment(String department) {
        this.department = department;
    }
    
    // Implementing abstract method
    @Override
    public String getRole() {
        return "Employee";
    }
    
    // Method overriding (Polymorphism)
    @Override
    public String getDisplayInfo() {
        return "Employee: " + getFullName() + " - " + position + " (PKR " + salary + ")";
    }
}
