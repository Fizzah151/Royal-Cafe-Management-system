package cafe.models;

// Inheritance - ChineseDish extends MenuItem
public class ChineseDish extends MenuItem {
    private String spiceLevel;
    private boolean isVegetarian;
    private String cookingStyle;
    
    public ChineseDish(int itemId, String name, String description, double price, 
                      String spiceLevel, boolean isVegetarian, String cookingStyle) {
        super(itemId, name, description, price, "Chinese Dish");
        this.spiceLevel = spiceLevel;
        this.isVegetarian = isVegetarian;
        this.cookingStyle = cookingStyle;
    }
    
    // Encapsulation
    public String getSpiceLevel() {
        return spiceLevel;
    }
    
    public void setSpiceLevel(String spiceLevel) {
        this.spiceLevel = spiceLevel;
    }
    
    public boolean isVegetarian() {
        return isVegetarian;
    }
    
    public void setVegetarian(boolean vegetarian) {
        isVegetarian = vegetarian;
    }
    
    public String getCookingStyle() {
        return cookingStyle;
    }
    
    public void setCookingStyle(String cookingStyle) {
        this.cookingStyle = cookingStyle;
    }
    
    // Implementing abstract method
    @Override
    public String getItemType() {
        return "Chinese Dish";
    }
    
    // Method overriding (Polymorphism)
    @Override
    public String getDisplayInfo() {
        return getName() + " - PKR " + getPrice() + " (Chinese - " + spiceLevel + " spice)";
    }
}
