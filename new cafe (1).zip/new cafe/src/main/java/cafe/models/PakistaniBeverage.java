package cafe.models;

// Inheritance - PakistaniBeverage extends MenuItem
public class PakistaniBeverage extends MenuItem {
    private String temperature; // Hot/Cold/Room Temperature
    private boolean isSugarFree;
    private String size; // Small/Medium/Large
    
    public PakistaniBeverage(int itemId, String name, String description, double price, 
                           String temperature, boolean isSugarFree, String size) {
        super(itemId, name, description, price, "Pakistani Beverage");
        this.temperature = temperature;
        this.isSugarFree = isSugarFree;
        this.size = size;
    }
    
    // Encapsulation
    public String getTemperature() {
        return temperature;
    }
    
    public void setTemperature(String temperature) {
        this.temperature = temperature;
    }
    
    public boolean isSugarFree() {
        return isSugarFree;
    }
    
    public void setSugarFree(boolean sugarFree) {
        isSugarFree = sugarFree;
    }
    
    public String getSize() {
        return size;
    }
    
    public void setSize(String size) {
        this.size = size;
    }
    
    // Implementing abstract method
    @Override
    public String getItemType() {
        return "Pakistani Beverage";
    }
    
    // Method overriding (Polymorphism)
    @Override
    public String getDisplayInfo() {
        return getName() + " - PKR " + getPrice() + " (" + size + " " + temperature + ")";
    }
    
    // Method overloading specific to beverages
    public double calculateTotal(int quantity, String customSize) {
        double sizeMultiplier = 1.0;
        switch (customSize.toLowerCase()) {
            case "small": sizeMultiplier = 0.8; break;
            case "large": sizeMultiplier = 1.2; break;
            default: sizeMultiplier = 1.0; break;
        }
        return getPrice() * quantity * sizeMultiplier;
    }
}
