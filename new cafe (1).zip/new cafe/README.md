# Cafe Management System

A comprehensive Java-based Cafe Management System demonstrating Object-Oriented Programming concepts using JavaFX for the GUI.

## Features

### 1. User Management
- **Admin Login & Registration**: Secure admin authentication
- **Employee Management**: Add, edit, delete, and view employees
- **Customer Registration**: Self-service customer account creation

### 2. Menu Management
- **Chinese Dishes**: Add and manage Chinese cuisine items
- **Pakistani Beverages**: Manage traditional Pakistani drinks
- **Price Management**: All prices in PKR currency
- **Availability Control**: Toggle item availability

### 3. Order Management
- **Customer Orders**: Place and track orders
- **Order Status**: Real-time order status updates
- **Loyalty Points**: Automatic points calculation (1 point per 100 PKR)

## OOP Concepts Demonstrated

### 1. Inheritance
- `User` → `Admin`, `Employee`, `Customer`
- `MenuItem` → `ChineseDish`, `PakistaniBeverage`

### 2. Polymorphism
- Method overriding in subclasses
- Method overloading for different parameter sets

### 3. Encapsulation
- Private fields with public getters/setters
- Data hiding and controlled access

### 4. Abstraction
- Abstract classes: `User`, `MenuItem`
- Abstract methods implemented by subclasses

## Default Login Credentials

- **Admin**: username: `admin`, password: `admin123`
- **Employee**: username: `emp001`, password: `emp123`
- **Customer**: Register new account through the application

## Sample Menu Items

### Chinese Dishes
- Chicken Chow Mein - PKR 450
- Sweet and Sour Chicken - PKR 520
- Vegetable Spring Rolls - PKR 280
- Beef Black Bean - PKR 580
- Kung Pao Chicken - PKR 500

### Pakistani Beverages
- Chai - PKR 80
- Lassi - PKR 120
- Rooh Afza - PKR 100
- Kashmiri Chai - PKR 150
- Fresh Lime Water - PKR 90

## How to Run

### Prerequisites
- Java 11 or higher
- Maven 3.6+
- JavaFX SDK

### Running the Application

1. **Using Maven:**
   \`\`\`bash
   mvn clean javafx:run
   \`\`\`

2. **Using IDE (VS Code):**
   - Install Java Extension Pack
   - Open the project folder
   - Run `CafeManagementApp.java`

3. **Creating Executable JAR:**
   \`\`\`bash
   mvn clean package
   java -jar target/cafe-management-system-1.0.0.jar
   \`\`\`

## Project Structure

\`\`\`
src/main/java/cafe/
├── models/
│   ├── User.java (Abstract)
│   ├── Admin.java
│   ├── Employee.java
│   ├── Customer.java
│   ├── MenuItem.java (Abstract)
│   ├── ChineseDish.java
│   ├── PakistaniBeverage.java
│   ├── Order.java
│   └── OrderItem.java
├── services/
│   ├── UserService.java
│   ├── MenuService.java
│   └── OrderService.java
└── CafeManagementApp.java (Main Class)
\`\`\`

## Technologies Used

- **Java 11**: Core programming language
- **JavaFX**: GUI framework
- **Maven**: Build and dependency management
- **OOP Principles**: Inheritance, Polymorphism, Encapsulation, Abstraction

## Future Enhancements

- Database integration (MySQL/PostgreSQL)
- Receipt printing functionality
- Advanced reporting and analytics
- Multi-language support
- Online ordering system

## Author

Developed as an educational project to demonstrate OOP concepts in Java with JavaFX GUI.
